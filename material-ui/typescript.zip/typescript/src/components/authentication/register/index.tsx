export { default as RegisterAmplify } from './RegisterAmplify';
export { default as RegisterAuth0 } from './RegisterAuth0';
export { default as RegisterFirebase } from './RegisterFirebase';
export { default as RegisterJWT } from './RegisterJWT';
