export { default as PasswordResetAmplify } from './PasswordResetAmplify';
