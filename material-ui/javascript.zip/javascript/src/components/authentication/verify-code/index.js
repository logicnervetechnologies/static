export { default as VerifyCodeAmplify } from './VerifyCodeAmplify';
